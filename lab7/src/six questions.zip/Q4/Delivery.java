package Q4;

public class Delivery {
    protected void calculateDeliveryTime(){
        System.out.println("Cost Delivery");
    }
}
class ExpressDelivery extends Delivery{
    protected void calculateDeliveryTime(){
        System.out.println("Cost Express Delivery");
    }
}
class StandardDeliver extends Delivery{
    protected void calculateDeliveryTime(){
        System.out.println("Cost Standard Delivery");
    }
}
class Main{
    public static void main(String[] args) {
        Delivery express = new ExpressDelivery();
        Delivery standard = new StandardDeliver();
        System.out.println("After upcasting below is down casting>");
//        ExpressDelivery expressDOWN;
//        StandardDeliver standardDOWN;
        if(express instanceof ExpressDelivery)
        {
            ExpressDelivery expressDOWN =(ExpressDelivery) express;
        expressDOWN.calculateDeliveryTime();
        }
        else{
            System.out.println("ERROR");
        }

        if(standard instanceof StandardDeliver)
        {
            StandardDeliver standardDOWN =(StandardDeliver) standard;
        standardDOWN.calculateDeliveryTime();
        }
        else{
            System.out.println("ERROR");
        }
    }
}