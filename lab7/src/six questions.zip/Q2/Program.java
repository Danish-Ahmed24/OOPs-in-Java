package Q2;

public class Program {
    public static void main(String[] args) {
        double doubleNum = 43.55d;
        int intNum = (int)doubleNum;
        System.out.println("Double: "+doubleNum);
        System.out.println("After explicit casting Integer: "+intNum);
    }
}
