package Q5;

import java.security.spec.EllipticCurve;

public class Product {
    protected void showDetails()
    {
        System.out.println("Showing general details!");
    }
}
class Electronics extends Product {
    protected void showDetails()
    {
        System.out.println("Shwoing electronics details");
    }
    void applyWarranty(){
        System.out.println("Applying warranty");
    }
}
class Clothing extends Product{
    protected void showDetails()
    {
        System.out.println("Shwoing Cloths details");
    }
    void applyDiscount(){
        System.out.println("Applying discount");
    }
}
class Main{
    public static void main(String[] args) {
        System.out.println("UP Cast");
        Product electronic = new Electronics();
        Product cloth = new Clothing();
        cloth.showDetails();
        electronic.showDetails();
        System.out.println("Down Cast");
        Electronics clothDOWN = (Electronics) electronic;
        Clothing productDOWN = (Clothing) cloth;
        clothDOWN.applyWarranty();
        productDOWN.applyDiscount();


    }
}