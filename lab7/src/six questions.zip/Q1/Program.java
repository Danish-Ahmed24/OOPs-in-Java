package Q1;


public class Program {

    public static void main(String[] args) {
        int integerNum = 3;
        double doubleNum = integerNum;
        System.out.println("Integer: "+integerNum);
        System.out.println("Double: "+doubleNum);
    }
}
